# 交接檔

## 目前進度

- 已建立 Codex Skill：`taiwan-worldcup-trip-planner/`。
- Skill 已包含 `SKILL.md`、`assets/worldcup-trip-prompt.md`、`assets/content-snippets.md`、`assets/frontend-template/`、`references/worldcup-trip-report-template.md`、`references/worldcup-trip-html-template.html`、`references/official-sources.md`、`references/itinerary-framework.md`。
- 已建立作品：`worldcup-trip-planner-app/`，是一個可直接開啟的靜態網頁行程規劃器。
- 已建立 `README.md` 與 `AGENTS.md`。
- 已依使用者最新方向補強定位：第一項是「2026 世界盃台灣球迷行程規劃 Skill」，第二項是像「標準公式計算器」的互動式網頁作品。
- 已新增 `skill-repository-upload/`，內容只有 `assets/`、`references/`、`SKILL.md`，可直接對應 GitHub 截圖中的 Skill repository 結構。其中 `assets/worldcup-trip-prompt.md` 對應使用指令，`references/` 內含 Markdown 與 HTML 範本。

## 設計方向

作品服務對象是前往美國看 2026 世界盃的台灣球迷。功能重點不是單純介紹賽事，而是協助使用者比較觀賽區域、天數、場次、移動強度與預算，並輸出路線、預算、行程骨架與風險提醒。

作品邏輯可用這句話說明：`預算 + 天數 + 城市 + 場次 + 移動強度 = 行程建議 + 預算估算 + 風險提醒`。

中文用語已改成台灣常用說法，避免「賦能」、「一站式」、「閉環」等制式或不自然詞彙。

## 待辦事項

- 若要真正發布到 GitHub，需要先讓 GitHub App 安裝到目標帳號或提供可寫入的 repository。
- 本環境目前找不到 `git` 指令，無法用本機 CLI 初始化、commit、push。
- Node.js 與內建瀏覽器在此沙盒環境被權限擋下，尚未完成實際瀏覽器截圖驗證。
- 第一個 GitHub repository 建議直接上傳 `skill-repository-upload/` 裡的三個項目。
- 第二個 GitHub repository 建議上傳 `worldcup-trip-planner-app/`，必要時再附上根目錄 `README.md`。
- 若有目標 GitHub repo，可用 connector 將檔案逐一建立，或在有 Git 的環境中執行：
  - `git init`
  - `git add .`
  - `git commit -m "Add Taiwan World Cup trip planner skill and app"`
  - `git branch -M main`
  - `git remote add origin <repo-url>`
  - `git push -u origin main`

## 驗證建議

- 已完成簡化檢查：Skill frontmatter、必要檔案、作品 HTML/JS selector 對應。
- 官方 `quick_validate.py` 需要 `PyYAML`，目前環境缺少該套件，因此未能執行。
- 開啟作品：`worldcup-trip-planner-app/index.html`
- 檢查手機寬度下是否仍能正常閱讀與操作。
