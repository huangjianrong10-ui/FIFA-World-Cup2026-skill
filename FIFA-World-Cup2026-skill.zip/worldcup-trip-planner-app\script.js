const regions = {
  west: {
    label: "西岸穩定型",
    route: "桃園出發，先進洛杉磯調整時差，再銜接舊金山灣區或西雅圖。這條線適合第一次赴美看球，移動距離相對可控，也比較容易保留休息時間。",
    base: 92000,
    days: ["抵達洛杉磯，入住交通方便的區域", "安排第一場比賽與城市走訪", "轉往舊金山灣區或西雅圖", "第二場比賽，隔天保留彈性時間", "返回洛杉磯或直接銜接返台航班"],
    risks: ["住宿價格波動", "比賽日交通管制", "時差影響", "返程航班銜接"]
  },
  central: {
    label: "多場追賽型",
    route: "以達拉斯或休士頓作為主基地，再用國內線銜接堪薩斯城或亞特蘭大。這條線能追較多場比賽，但航班延誤與轉乘緩衝要抓得更保守。",
    base: 98000,
    days: ["抵達達拉斯或休士頓", "完成第一場比賽與周邊移動測試", "搭國內線前往第二城市", "安排第二場或第三場比賽", "回到主要國際機場返台"],
    risks: ["高溫與午後雷雨", "國內線延誤", "跨城市交通成本", "行李轉運"]
  },
  east: {
    label: "城市體驗型",
    route: "以紐約紐澤西為核心，搭配費城或波士頓；若加入邁阿密，建議另外切一段航班。這條線城市體驗豐富，但住宿與交通預算要抓高。",
    base: 108000,
    days: ["抵達紐約，先處理時差與交通卡", "安排紐約紐澤西比賽", "搭鐵路或短程航班前往第二城市", "安排城市走訪與第二場比賽", "保留購物或延誤緩衝後返台"],
    risks: ["住宿費偏高", "深夜散場交通", "熱門景點排隊", "城市間票價波動"]
  }
};

const controls = {
  region: document.querySelector("#region"),
  days: document.querySelector("#days"),
  matches: document.querySelector("#matches"),
  pace: document.querySelector("#pace"),
  budget: document.querySelector("#budget"),
  firstTrip: document.querySelector("#firstTrip"),
  officialOnly: document.querySelector("#officialOnly")
};

const output = {
  daysValue: document.querySelector("#daysValue"),
  matchesValue: document.querySelector("#matchesValue"),
  paceValue: document.querySelector("#paceValue"),
  score: document.querySelector("#score"),
  verdict: document.querySelector("#verdict"),
  routeText: document.querySelector("#routeText"),
  budgetText: document.querySelector("#budgetText"),
  itinerary: document.querySelector("#itinerary"),
  nextSteps: document.querySelector("#nextSteps"),
  riskList: document.querySelector("#riskList")
};

function money(value) {
  return new Intl.NumberFormat("zh-TW", {
    style: "currency",
    currency: "TWD",
    maximumFractionDigits: 0
  }).format(value);
}

function list(items) {
  return items.map((item) => `<li>${item}</li>`).join("");
}

function analyze() {
  const region = regions[controls.region.value];
  const days = Number(controls.days.value);
  const matches = Number(controls.matches.value);
  const pace = Number(controls.pace.value);
  const budget = Number(controls.budget.value);
  const firstTripPenalty = controls.firstTrip.checked && pace >= 4 ? 8 : 0;
  const officialBonus = controls.officialOnly.checked ? 4 : -6;
  const estimate = region.base + days * 5200 + matches * 18500 + Math.max(0, pace - 3) * 9000;
  const budgetGap = budget - estimate;
  const score = Math.max(35, Math.min(96, 78 + Math.floor(budgetGap / 9000) + officialBonus - firstTripPenalty - Math.max(0, matches - 3) * 5));

  output.daysValue.textContent = `${days} 天`;
  output.matchesValue.textContent = `${matches} 場`;
  output.paceValue.textContent = `${pace}`;
  output.score.textContent = score;
  output.score.style.color = score >= 75 ? "var(--green)" : score >= 60 ? "var(--gold)" : "var(--red)";
  output.verdict.textContent = score >= 75
    ? "節奏穩定，預算與移動安排大致可行。"
    : score >= 60
      ? "可以規劃，但要降低移動密度或提高預算緩衝。"
      : "行程偏硬，建議先減少城市或場次。";
  output.routeText.textContent = region.route;
  output.budgetText.textContent = `以 ${days} 天、${matches} 場、移動強度 ${pace} 估算，每人約 ${money(estimate)}。目前預算 ${money(budget)}，${budgetGap >= 0 ? `尚有 ${money(budgetGap)} 緩衝。` : `約超出 ${money(Math.abs(budgetGap))}。`}`;
  output.itinerary.innerHTML = list(region.days);
  output.nextSteps.innerHTML = list([
    "先確認護照效期、ESTA 資格與停留天數。",
    "以 FIFA 官方票務或官方 hospitality 管道為優先。",
    "球票確定後立刻鎖定可取消住宿。",
    "跨城市移動至少保留半天緩衝，避免比賽日當天長途轉乘。"
  ]);
  output.riskList.innerHTML = [...region.risks, "旅遊保險", "手機網路", "匯率變動"].map((item) => `<span class="risk">${item}</span>`).join("");
}

document.querySelector("#calculate").addEventListener("click", analyze);
Object.values(controls).forEach((control) => control.addEventListener("input", analyze));
Object.values(controls).forEach((control) => control.addEventListener("change", analyze));
analyze();
